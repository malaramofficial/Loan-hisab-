# लोन हिसाब (Android नेटिव ऐप)

Kotlin + Jetpack Compose + Room। पूरी तरह ऑफ़लाइन: कोई वेबसाइट, सर्वर, लॉगिन या इंटरनेट permission नहीं।

## चलाने का तरीका
1. Android Studio (नया संस्करण) में **Open** → यह `LoanHisab` फ़ोल्डर चुनें।
2. Gradle Sync पूरा होने दें (पहली बार इंटरनेट चाहिए, Gradle wrapper और लाइब्रेरी डाउनलोड होंगी)।
3. फ़ोन USB से जोड़ें (USB debugging चालू) और **Run ▶** दबाएँ।
4. APK के लिए: **Build → Build Bundle(s) / APK(s) → Build APK(s)**।
5. Play Store के लिए: **Build → Generate Signed App Bundle** और अपनी keystore इस्तेमाल करें।

## स्क्रीन
- **होम**: उपलब्ध बैलेंस, कुल लोन, कुल खर्च, हाल की 5 एंट्री
- **एंट्री**: सभी एंट्री महीने के हिसाब से, खोज, नई एंट्री बटन
- **रिपोर्ट**: महीने का फ़िल्टर, किसको दिए / किस काम में / किसने भेजे का ब्रेकडाउन
- **सेटिंग**: नाम, कुल लोन, बैकअप सेव/रिस्टोर, CSV एक्सपोर्ट

## बैकअप फ़ाइल का फ़ॉर्मेट (JSON)
```json
{
  "app": "loan_hisab",
  "version": 1,
  "userName": "नाम",
  "totalLoanPaise": 75332200,
  "expenses": [
    {
      "date": "2026-11-05",
      "toWhom": "नगा राम",
      "purpose": "रोकड़",
      "paidBy": "बैंक से",
      "amountPaise": 23200000,
      "note": "सामान्य खर्च के लिए"
    }
  ]
}
```
रकम पैसे में लिखी जाती है: ₹1 = 100। इसी फ़ॉर्मेट में फ़ाइल बनाकर पुरानी एंट्री रिस्टोर से लाई जा सकती हैं।

## बदलने लायक चीज़ें
- पैकेज/ऐप ID: `app/build.gradle.kts` में `applicationId` (अभी `com.loanhisab.app`)
- रंग: `ui/theme/Theme.kt`
- सबसे कम Android संस्करण: Android 8.0 (API 26)
