# Room और Compose अपने consumer rules साथ लाते हैं; अलग से कुछ ज़रूरी नहीं।
