package com.loanhisab.app

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.loanhisab.app.ui.AppViewModel
import com.loanhisab.app.ui.EntriesScreen
import com.loanhisab.app.ui.EntrySheet
import com.loanhisab.app.ui.HomeScreen
import com.loanhisab.app.ui.ReportScreen
import com.loanhisab.app.ui.SettingsScreen
import com.loanhisab.app.ui.theme.LoanHisabTheme
import com.loanhisab.app.util.parseAmountToPaise
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // ऐप का थीम हल्का ही है, इसलिए सिस्टम बार के आइकन हमेशा गहरे रखे हैं
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent {
            LoanHisabTheme {
                LoanHisabApp()
            }
        }
    }
}

private data class TabItem(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val tabs = listOf(
    TabItem("होम", Icons.Rounded.Home),
    TabItem("एंट्री", Icons.Rounded.ReceiptLong),
    TabItem("रिपोर्ट", Icons.Rounded.BarChart),
    TabItem("सेटिंग", Icons.Rounded.Settings)
)

@Composable
fun LoanHisabApp(vm: AppViewModel = viewModel()) {
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    val expenses by vm.expenses.collectAsStateWithLifecycle()
    val name by vm.userName.collectAsStateWithLifecycle()
    val loanPaise by vm.totalLoanPaise.collectAsStateWithLifecycle()
    val setupDone by vm.setupDone.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var sheetOpen by rememberSaveable { mutableStateOf(false) }
    var editingId by rememberSaveable { mutableStateOf<Long?>(null) }
    val editing = editingId?.let { id -> expenses.firstOrNull { it.id == id } }

    val spent = expenses.sumOf { it.amountPaise }

    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }

    BackHandler(enabled = tab != 0) { tab = 0 }

    val exportBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) vm.exportBackup(uri) }
    val exportCsv = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri -> if (uri != null) vm.exportCsv(uri) }
    val importBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.importBackup(uri) }

    fun openNew() {
        editingId = null
        sheetOpen = true
    }

    fun openEdit(id: Long) {
        editingId = id
        sheetOpen = true
    }

    Scaffold(
        containerColor = cs.background,
        topBar = { AppTopBar() },
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            if (tab == 1) {
                ExtendedFloatingActionButton(
                    onClick = { openNew() },
                    containerColor = cs.primary,
                    contentColor = cs.onPrimary
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("नई एंट्री", fontWeight = FontWeight.Bold)
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = cs.surface) {
                tabs.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(item.icon, contentDescription = null) },
                        label = { Text(item.label, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (tab) {
                0 -> HomeScreen(
                    name = name,
                    loanPaise = loanPaise,
                    spentPaise = spent,
                    recent = expenses.take(5),
                    onAdd = { openNew() },
                    onEdit = { openEdit(it.id) },
                    onSeeAll = { tab = 1 }
                )

                1 -> EntriesScreen(expenses = expenses, onEdit = { openEdit(it.id) })

                2 -> ReportScreen(expenses = expenses, loanPaise = loanPaise)

                else -> SettingsScreen(
                    name = name,
                    loanPaise = loanPaise,
                    entryCount = expenses.size,
                    onNameChange = vm::setName,
                    onLoanChange = vm::setLoan,
                    onExportBackup = {
                        exportBackup.launch("loan_hisab_backup_${LocalDate.now()}.json")
                    },
                    onRestore = { importBackup.launch(arrayOf("*/*")) },
                    onExportCsv = {
                        exportCsv.launch("loan_hisab_entries_${LocalDate.now()}.csv")
                    }
                )
            }
        }
    }

    if (sheetOpen) {
        EntrySheet(
            initial = editing,
            allExpenses = expenses,
            onDismiss = { sheetOpen = false },
            onSave = { expense ->
                vm.save(expense)
                sheetOpen = false
            },
            onDelete = { expense ->
                sheetOpen = false
                vm.delete(expense)
                scope.launch {
                    snackbar.currentSnackbarData?.dismiss()
                    val result = snackbar.showSnackbar(
                        message = "एंट्री हटा दी गई",
                        actionLabel = "वापस लाएँ",
                        withDismissAction = true
                    )
                    if (result == SnackbarResult.ActionPerformed) vm.undoDelete(expense)
                }
            }
        )
    }

    if (!setupDone) {
        SetupDialog(
            onSkip = vm::skipSetup,
            onDone = { userName, loan -> vm.finishSetup(userName, loan) }
        )
    }
}

@Composable
private fun AppTopBar() {
    val cs = MaterialTheme.colorScheme
    Surface(color = cs.surface, shadowElevation = 1.dp) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .background(cs.primaryContainer, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.AccountBalanceWallet, contentDescription = null, tint = cs.primary)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("लोन हिसाब", style = MaterialTheme.typography.titleLarge)
                Text(
                    "एक बैंक • एक लोन",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        }
    }
}

/** पहली बार खोलने पर नाम और कुल लोन पूछता है; दोनों बाद में सेटिंग से बदले जा सकते हैं */
@Composable
private fun SetupDialog(onSkip: () -> Unit, onDone: (String, Long) -> Unit) {
    var userName by remember { mutableStateOf("") }
    var loanText by remember { mutableStateOf("") }
    var loanError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = {},
        title = { Text("शुरू करें") },
        text = {
            Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                Text(
                    "अपना नाम और अब तक मिला कुल लोन लिखें। यह बाद में सेटिंग से बदला जा सकता है।",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = userName,
                    onValueChange = { userName = it },
                    label = { Text("आपका नाम") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )
                OutlinedTextField(
                    value = loanText,
                    onValueChange = {
                        loanText = it
                        loanError = false
                    },
                    label = { Text("कुल प्राप्त लोन (रुपये)") },
                    singleLine = true,
                    isError = loanError,
                    supportingText = if (loanError) ({ Text("सही रकम लिखें") }) else null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(16.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val loan = if (loanText.isBlank()) 0L else parseAmountToPaise(loanText, allowZero = true)
                if (loan == null) loanError = true else onDone(userName, loan)
            }) { Text("शुरू करें", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onSkip) { Text("बाद में") } }
    )
}
