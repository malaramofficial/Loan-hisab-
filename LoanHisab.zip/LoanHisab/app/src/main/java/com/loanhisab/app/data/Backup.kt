package com.loanhisab.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class BackupData(
    val userName: String,
    val totalLoanPaise: Long,
    val expenses: List<Expense>
)

object Backup {
    private const val APP_ID = "loan_hisab"

    fun toJson(userName: String, totalLoanPaise: Long, list: List<Expense>): String {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(
                JSONObject().apply {
                    put("id", e.id)
                    put("date", LocalDate.ofEpochDay(e.dateEpochDay).toString())
                    put("toWhom", e.toWhom)
                    put("purpose", e.purpose)
                    put("paidBy", e.paidBy)
                    put("amountPaise", e.amountPaise)
                    put("note", e.note)
                    put("createdAt", e.createdAt)
                }
            )
        }
        return JSONObject().apply {
            put("app", APP_ID)
            put("version", 1)
            put("userName", userName)
            put("totalLoanPaise", totalLoanPaise)
            put("expenses", arr)
        }.toString(2)
    }

    /** गलत या दूसरी फ़ाइल होने पर exception फेंकता है। */
    fun parse(text: String): BackupData {
        val root = JSONObject(text)
        require(root.optString("app") == APP_ID) { "यह लोन हिसाब की बैकअप फ़ाइल नहीं है" }
        val arr = root.getJSONArray("expenses")
        val list = (0 until arr.length()).map { i ->
            val x = arr.getJSONObject(i)
            Expense(
                id = x.optLong("id", 0L),
                dateEpochDay = LocalDate.parse(x.getString("date")).toEpochDay(),
                toWhom = x.getString("toWhom"),
                purpose = x.getString("purpose"),
                paidBy = x.getString("paidBy"),
                amountPaise = x.getLong("amountPaise"),
                note = x.optString("note", ""),
                createdAt = x.optLong("createdAt", System.currentTimeMillis())
            )
        }
        return BackupData(
            userName = root.optString("userName", ""),
            totalLoanPaise = root.optLong("totalLoanPaise", 0L),
            expenses = list
        )
    }

    /** Excel/Sheets में हिंदी ठीक खुले इसलिए शुरू में BOM जोड़ा गया है। */
    fun toCsv(list: List<Expense>): String {
        val sb = StringBuilder("﻿")
        sb.append("तारीख,किसको भेजे,किस काम के लिए,किसने भेजे,रुपये,अतिरिक्त जानकारी\r\n")
        list.sortedWith(compareBy<Expense> { it.dateEpochDay }.thenBy { it.id }).forEach { e ->
            sb.append(LocalDate.ofEpochDay(e.dateEpochDay).toString()).append(',')
                .append(csv(e.toWhom)).append(',')
                .append(csv(e.purpose)).append(',')
                .append(csv(e.paidBy)).append(',')
                .append(String.format("%d.%02d", e.amountPaise / 100, e.amountPaise % 100)).append(',')
                .append(csv(e.note)).append("\r\n")
        }
        return sb.toString()
    }

    private fun csv(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""
}
