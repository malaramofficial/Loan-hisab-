package com.loanhisab.app.data

import android.content.Context

/** छोटी सेटिंग्स: नाम, कुल प्राप्त लोन (पैसे में) और पहली बार का सेटअप। */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("loan_hisab", Context.MODE_PRIVATE)

    var userName: String
        get() = sp.getString(KEY_NAME, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_NAME, value).apply()
        }

    var totalLoanPaise: Long
        get() = sp.getLong(KEY_LOAN, 0L)
        set(value) {
            sp.edit().putLong(KEY_LOAN, value).apply()
        }

    var setupDone: Boolean
        get() = sp.getBoolean(KEY_SETUP, false)
        set(value) {
            sp.edit().putBoolean(KEY_SETUP, value).apply()
        }

    private companion object {
        const val KEY_NAME = "name"
        const val KEY_LOAN = "loan_paise"
        const val KEY_SETUP = "setup_done"
    }
}
