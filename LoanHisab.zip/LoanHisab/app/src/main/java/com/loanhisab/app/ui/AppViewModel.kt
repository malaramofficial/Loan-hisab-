package com.loanhisab.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.loanhisab.app.data.AppDatabase
import com.loanhisab.app.data.Backup
import com.loanhisab.app.data.Expense
import com.loanhisab.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.get(app)
    private val dao = db.expenseDao()
    private val prefs = Prefs(app)

    val expenses: StateFlow<List<Expense>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _userName = MutableStateFlow(prefs.userName)
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _totalLoanPaise = MutableStateFlow(prefs.totalLoanPaise)
    val totalLoanPaise: StateFlow<Long> = _totalLoanPaise.asStateFlow()

    private val _setupDone = MutableStateFlow(prefs.setupDone)
    val setupDone: StateFlow<Boolean> = _setupDone.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    // ---- सेटिंग्स ----

    fun finishSetup(name: String, loanPaise: Long) {
        setName(name)
        setLoan(loanPaise)
        prefs.setupDone = true
        _setupDone.value = true
    }

    fun skipSetup() {
        prefs.setupDone = true
        _setupDone.value = true
    }

    fun setName(name: String) {
        val clean = name.trim()
        prefs.userName = clean
        _userName.value = clean
    }

    fun setLoan(paise: Long) {
        prefs.totalLoanPaise = paise
        _totalLoanPaise.value = paise
    }

    // ---- एंट्री ----

    fun save(expense: Expense) {
        viewModelScope.launch {
            if (expense.id == 0L) dao.insert(expense) else dao.update(expense)
            _messages.emit("एंट्री सेव हो गई")
        }
    }

    fun delete(expense: Expense) {
        viewModelScope.launch { dao.delete(expense) }
    }

    /** हटाई गई एंट्री को उसी id के साथ वापस डालता है (Undo के लिए) */
    fun undoDelete(expense: Expense) {
        viewModelScope.launch { dao.insert(expense) }
    }

    // ---- बैकअप / एक्सपोर्ट ----

    fun exportBackup(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = runCatching {
                val json = Backup.toJson(_userName.value, _totalLoanPaise.value, expenses.value)
                getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                    ?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                    ?: error("फ़ाइल नहीं खुली")
            }.isSuccess
            _messages.emit(if (ok) "बैकअप सेव हो गया" else "बैकअप सेव नहीं हो सका")
        }
    }

    fun exportCsv(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = runCatching {
                val csv = Backup.toCsv(expenses.value)
                getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                    ?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                    ?: error("फ़ाइल नहीं खुली")
            }.isSuccess
            _messages.emit(if (ok) "CSV फ़ाइल सेव हो गई" else "CSV सेव नहीं हो सकी")
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val data = runCatching {
                val text = getApplication<Application>().contentResolver.openInputStream(uri)
                    ?.use { it.readBytes().toString(Charsets.UTF_8) }
                    ?: error("फ़ाइल नहीं खुली")
                Backup.parse(text)
            }.getOrNull()

            if (data == null) {
                _messages.emit("यह सही बैकअप फ़ाइल नहीं है, कुछ बदला नहीं गया")
                return@launch
            }
            db.withTransaction {
                dao.clear()
                dao.insertAll(data.expenses)
            }
            setName(data.userName)
            setLoan(data.totalLoanPaise)
            prefs.setupDone = true
            _setupDone.value = true
            _messages.emit("${data.expenses.size} एंट्री रिस्टोर हो गईं")
        }
    }
}
