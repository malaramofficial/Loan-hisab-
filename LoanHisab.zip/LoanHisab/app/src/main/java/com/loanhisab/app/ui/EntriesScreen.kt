package com.loanhisab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.loanhisab.app.data.Expense
import com.loanhisab.app.util.formatRupees
import com.loanhisab.app.util.monthLabel
import com.loanhisab.app.util.monthOf

@Composable
fun EntriesScreen(expenses: List<Expense>, onEdit: (Expense) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var query by rememberSaveable { mutableStateOf("") }

    val filtered = remember(expenses, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) expenses
        else expenses.filter { e ->
            e.toWhom.lowercase().contains(q) ||
                e.purpose.lowercase().contains(q) ||
                e.paidBy.lowercase().contains(q) ||
                e.note.lowercase().contains(q) ||
                (e.amountPaise / 100).toString().contains(q)
        }
    }
    val total = filtered.sumOf { it.amountPaise }
    // सूची पहले से नई-से-पुरानी है, इसलिए groupBy का क्रम महीनों के हिसाब से सही रहता है
    val grouped = remember(filtered) { filtered.groupBy { monthOf(it.dateEpochDay) }.toList() }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("सभी एंट्री", style = MaterialTheme.typography.headlineMedium)
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("नाम, काम या रकम से खोजें") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Rounded.Close, contentDescription = "खोज हटाएँ")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )
                Text(
                    "${filtered.size} एंट्री • कुल −${formatRupees(total)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        }

        if (filtered.isEmpty()) {
            item {
                EmptyState(
                    if (expenses.isEmpty()) "अभी कोई एंट्री नहीं है।\nनीचे के बटन से पहला खर्च जोड़ें।"
                    else "इस खोज से कोई एंट्री नहीं मिली।"
                )
            }
        } else {
            grouped.forEach { (month, list) ->
                item(key = "header-$month") {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            monthLabel(month),
                            style = MaterialTheme.typography.titleMedium,
                            color = cs.primary
                        )
                        Text(
                            "−" + formatRupees(list.sumOf { it.amountPaise }),
                            style = MaterialTheme.typography.titleSmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
                items(list, key = { it.id }) { e ->
                    EntryCard(e, onEdit = { onEdit(e) })
                }
            }
        }
    }
}
