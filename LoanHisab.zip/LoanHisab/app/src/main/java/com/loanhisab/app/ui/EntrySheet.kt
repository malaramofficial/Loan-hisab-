package com.loanhisab.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loanhisab.app.data.Expense
import com.loanhisab.app.util.formatDate
import com.loanhisab.app.util.formatRupees
import com.loanhisab.app.util.paiseToInput
import com.loanhisab.app.util.parseAmountToPaise
import java.time.LocalDate

private const val DAY_MILLIS = 86_400_000L

/**
 * नई एंट्री जोड़ने या पुरानी एंट्री एडिट करने की शीट।
 * initial == null हो तो नई एंट्री बनती है।
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntrySheet(
    initial: Expense?,
    allExpenses: List<Expense>,
    onDismiss: () -> Unit,
    onSave: (Expense) -> Unit,
    onDelete: (Expense) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var date by remember { mutableLongStateOf(initial?.dateEpochDay ?: LocalDate.now().toEpochDay()) }
    var toWhom by remember { mutableStateOf(initial?.toWhom ?: "") }
    var purpose by remember { mutableStateOf(initial?.purpose ?: "") }
    // नई एंट्री में पिछली बार वाला "किसने भेजे" पहले से भर देते हैं
    var paidBy by remember { mutableStateOf(initial?.paidBy ?: allExpenses.firstOrNull()?.paidBy ?: "") }
    var amountText by remember { mutableStateOf(initial?.let { paiseToInput(it.amountPaise) } ?: "") }
    var note by remember { mutableStateOf(initial?.note ?: "") }

    var tried by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val amountPaise = parseAmountToPaise(amountText)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = cs.background
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .imePadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (initial == null) "नया खर्च दर्ज करें" else "पुरानी एंट्री में सुधार",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        if (initial == null) "नई एंट्री" else "एंट्री एडिट करें",
                        style = MaterialTheme.typography.headlineMedium
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "बंद करें")
                }
            }

            // तारीख
            FieldLabel("लेन-देन की तारीख", required = false)
            Box {
                OutlinedTextField(
                    value = formatDate(date),
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = { Icon(Icons.Rounded.CalendarMonth, contentDescription = null) },
                    shape = RoundedCornerShape(16.dp)
                )
                // readOnly TextField पर टैप सीधे नहीं पकड़ता, इसलिए ऊपर पारदर्शी परत रखी है
                Box(
                    Modifier
                        .matchParentSize()
                        .clickable { showDatePicker = true }
                )
            }

            FormField(
                label = "किसको पैसे भेजे?",
                value = toWhom,
                onValueChange = { toWhom = it },
                showError = tried && toWhom.isBlank(),
                errorText = "नाम लिखें",
                suggestions = allExpenses.map { it.toWhom }
            )
            FormField(
                label = "किस काम के लिए भेजे?",
                value = purpose,
                onValueChange = { purpose = it },
                showError = tried && purpose.isBlank(),
                errorText = "काम लिखें",
                suggestions = allExpenses.map { it.purpose }
            )
            FormField(
                label = "किसने पैसे भेजे?",
                value = paidBy,
                onValueChange = { paidBy = it },
                showError = tried && paidBy.isBlank(),
                errorText = "भेजने वाले का नाम लिखें",
                suggestions = allExpenses.map { it.paidBy }
            )
            FormField(
                label = "कितने रुपये भेजे?",
                value = amountText,
                onValueChange = { amountText = it },
                showError = tried && amountPaise == null,
                errorText = "सही रकम लिखें (ज़ीरो से ज़्यादा, पैसे दो अंक तक)",
                keyboardType = KeyboardType.Decimal,
                bold = true
            )
            FormField(
                label = "अतिरिक्त जानकारी (वैकल्पिक)",
                value = note,
                onValueChange = { note = it },
                required = false,
                singleLine = false
            )

            Spacer(Modifier.height(2.dp))
            Button(
                onClick = {
                    tried = true
                    if (toWhom.isNotBlank() && purpose.isNotBlank() && paidBy.isNotBlank() && amountPaise != null) {
                        onSave(
                            Expense(
                                id = initial?.id ?: 0L,
                                dateEpochDay = date,
                                toWhom = toWhom.trim(),
                                purpose = purpose.trim(),
                                paidBy = paidBy.trim(),
                                amountPaise = amountPaise,
                                note = note.trim(),
                                createdAt = initial?.createdAt ?: System.currentTimeMillis()
                            )
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    if (initial == null) "एंट्री सेव करें" else "बदलाव सेव करें",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            if (initial != null) {
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Rounded.Delete, contentDescription = null, tint = cs.error)
                    Spacer(Modifier.width(8.dp))
                    Text("यह एंट्री हटाएँ", color = cs.error, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showDatePicker) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = date * DAY_MILLIS)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { date = Math.floorDiv(it, DAY_MILLIS) }
                    showDatePicker = false
                }) { Text("ठीक है", fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("रद्द करें") } }
        ) {
            DatePicker(state = pickerState)
        }
    }

    if (showDeleteConfirm && initial != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("एंट्री हटाएँ?") },
            text = {
                Text("${initial.toWhom} • ${formatRupees(initial.amountPaise)}\nहटाने के बाद कुछ पल के लिए \"वापस लाएँ\" का विकल्प मिलेगा।")
            },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    onDelete(initial)
                }) { Text("हटाएँ", color = cs.error, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("रहने दें") } }
        )
    }
}

@Composable
private fun FieldLabel(text: String, required: Boolean) {
    Text(
        if (required) "$text *" else text,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun FormField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    required: Boolean = true,
    showError: Boolean = false,
    errorText: String = "",
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    bold: Boolean = false,
    suggestions: List<String> = emptyList()
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        FieldLabel(label, required)
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = singleLine,
            minLines = if (singleLine) 1 else 3,
            isError = showError,
            supportingText = if (showError) ({ Text(errorText) }) else null,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            textStyle = MaterialTheme.typography.bodyLarge.copy(
                fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
            ),
            shape = RoundedCornerShape(16.dp)
        )
        if (suggestions.isNotEmpty()) {
            SuggestionRow(all = suggestions, input = value, onPick = onValueChange)
        }
    }
}

/** पहले इस्तेमाल हुए नाम/काम, जो ज़्यादा बार आए वे पहले; टाइप करने पर छँटते जाते हैं */
@Composable
private fun SuggestionRow(all: List<String>, input: String, onPick: (String) -> Unit) {
    val options = remember(all, input) {
        val typed = input.trim().lowercase()
        all.map { it.trim() }
            .filter { it.isNotEmpty() }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .map { it.key }
            .filter { it.lowercase() != typed && (typed.isEmpty() || it.lowercase().contains(typed)) }
            .take(6)
    }
    if (options.isEmpty()) return
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            SuggestionChip(onClick = { onPick(option) }, label = { Text(option) })
        }
    }
}
