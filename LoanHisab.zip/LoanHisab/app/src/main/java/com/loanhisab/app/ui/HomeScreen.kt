package com.loanhisab.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.SouthWest
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loanhisab.app.data.Expense
import com.loanhisab.app.ui.theme.GreenBar
import com.loanhisab.app.ui.theme.GreenDark
import com.loanhisab.app.ui.theme.GreenPrimary
import com.loanhisab.app.util.formatRupees

@Composable
fun HomeScreen(
    name: String,
    loanPaise: Long,
    spentPaise: Long,
    recent: List<Expense>,
    onAdd: () -> Unit,
    onEdit: (Expense) -> Unit,
    onSeeAll: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    "आपका लोन खाता",
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    if (name.isBlank()) "नमस्ते" else "नमस्ते, $name",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    "हर रुपये का साफ और सुरक्षित हिसाब।",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        }
        item { BalanceCard(loanPaise, spentPaise) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(
                    label = "कुल प्राप्त लोन",
                    value = formatRupees(loanPaise),
                    caption = "शुरुआती राशि",
                    icon = Icons.Rounded.AccountBalanceWallet,
                    tint = GreenPrimary,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    label = "अब तक खर्च",
                    value = formatRupees(spentPaise),
                    caption = "दर्ज खर्च",
                    icon = Icons.Rounded.SouthWest,
                    tint = cs.error,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            Button(
                onClick = onAdd,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("नई खर्च एंट्री जोड़ें", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
        item {
            SectionHeader(
                title = "हाल की एंट्री",
                subtitle = "नवीनतम लेन-देन",
                actionText = "सभी देखें",
                onAction = onSeeAll
            )
        }
        if (recent.isEmpty()) {
            item { EmptyState("अभी कोई एंट्री नहीं है।\nऊपर के बटन से पहला खर्च जोड़ें।") }
        } else {
            items(recent, key = { it.id }) { e ->
                EntryCard(e, onEdit = { onEdit(e) })
            }
        }
    }
}

@Composable
private fun BalanceCard(loanPaise: Long, spentPaise: Long) {
    val available = loanPaise - spentPaise
    val fraction = if (loanPaise > 0) (spentPaise.toFloat() / loanPaise).coerceIn(0f, 1f) else 0f
    val percent = (fraction * 100).toInt()

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(GreenDark, Color(0xFF1B6B40))))
            .padding(22.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("अभी उपलब्ध बैलेंस", color = Color.White.copy(alpha = 0.85f))
            Text("● फ़ोन में सुरक्षित", color = GreenBar, style = MaterialTheme.typography.labelMedium)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            formatRupees(available),
            color = if (available < 0) Color(0xFFFFB4A2) else Color.White,
            fontSize = 44.sp,
            lineHeight = 52.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
        )
        if (available < 0) {
            Text(
                "दर्ज खर्च लोन की राशि से ज़्यादा है",
                color = Color(0xFFFFB4A2),
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                "कुल लोन ${formatRupees(loanPaise)}",
                color = Color.White.copy(alpha = 0.85f),
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                "कुल खर्च ${formatRupees(spentPaise)}",
                color = Color.White.copy(alpha = 0.85f),
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(50)),
            color = GreenBar,
            trackColor = Color.White.copy(alpha = 0.2f),
            gapSize = 0.dp,
            drawStopIndicator = {}
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "$percent% खर्च हो चुका",
            color = Color.White.copy(alpha = 0.75f),
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
private fun StatCard(
    label: String,
    value: String,
    caption: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        border = BorderStroke(1.dp, cs.outline)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(
                value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1
            )
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    caption,
                    style = MaterialTheme.typography.bodySmall,
                    color = tint,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
