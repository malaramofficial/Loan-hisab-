package com.loanhisab.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.loanhisab.app.data.Expense
import com.loanhisab.app.util.formatRupees
import com.loanhisab.app.util.monthLabel
import com.loanhisab.app.util.monthOf
import java.time.YearMonth

@Composable
fun ReportScreen(expenses: List<Expense>, loanPaise: Long) {
    val cs = MaterialTheme.colorScheme
    // चुना हुआ महीना "2026-11" की शक्ल में; null का मतलब सभी महीने
    var selected by rememberSaveable { mutableStateOf<String?>(null) }

    val months = remember(expenses) {
        expenses.map { monthOf(it.dateEpochDay) }.distinct().sortedDescending()
    }
    val selectedMonth = selected?.let { s -> months.firstOrNull { it.toString() == s } }
    val scoped = remember(expenses, selectedMonth) {
        if (selectedMonth == null) expenses else expenses.filter { monthOf(it.dateEpochDay) == selectedMonth }
    }
    val total = scoped.sumOf { it.amountPaise }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Text("रिपोर्ट", style = MaterialTheme.typography.headlineMedium) }

        if (expenses.isEmpty()) {
            item { EmptyState("रिपोर्ट बनाने के लिए पहले कुछ एंट्री जोड़ें।") }
            return@LazyColumn
        }

        item {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedMonth == null,
                    onClick = { selected = null },
                    label = { Text("सभी") }
                )
                months.forEach { ym ->
                    FilterChip(
                        selected = ym == selectedMonth,
                        onClick = { selected = ym.toString() },
                        label = { Text(monthLabel(ym)) }
                    )
                }
            }
        }

        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text(
                        if (selectedMonth == null) "अब तक का कुल खर्च" else "${monthLabel(selectedMonth)} का खर्च",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onPrimaryContainer
                    )
                    Text(
                        formatRupees(total),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = cs.onPrimaryContainer,
                        maxLines = 1
                    )
                    val extra = if (selectedMonth == null && loanPaise > 0) {
                        " • लोन में से ${formatRupees(loanPaise - total)} बाकी"
                    } else ""
                    Text(
                        "${scoped.size} एंट्री$extra",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onPrimaryContainer
                    )
                }
            }
        }

        if (selectedMonth == null && months.size > 1) {
            item {
                Breakdown(
                    title = "महीने के अनुसार",
                    rows = scoped.groupBy { monthOf(it.dateEpochDay) }
                        .map { (ym: YearMonth, list) -> monthLabel(ym) to list.sumOf { it.amountPaise } },
                    total = total,
                    sort = false
                )
            }
        }
        item { Breakdown("किसको दिए", groupBy(scoped) { it.toWhom }, total) }
        item { Breakdown("किस काम में लगे", groupBy(scoped) { it.purpose }, total) }
        item { Breakdown("किसने भेजे", groupBy(scoped) { it.paidBy }, total) }
    }
}

/** नाम के छोटे-बड़े अक्षर और खाली जगह का फ़र्क अनदेखा करके जोड़ता है */
private fun groupBy(list: List<Expense>, key: (Expense) -> String): List<Pair<String, Long>> =
    list.groupBy { key(it).trim().lowercase() }
        .map { (_, items) -> key(items.first()).trim() to items.sumOf { it.amountPaise } }

@Composable
private fun Breakdown(
    title: String,
    rows: List<Pair<String, Long>>,
    total: Long,
    sort: Boolean = true
) {
    val cs = MaterialTheme.colorScheme
    val ordered = if (sort) rows.sortedByDescending { it.second } else rows
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        border = BorderStroke(1.dp, cs.outline)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = cs.primary)
            ordered.forEach { (label, amount) ->
                val fraction = if (total > 0) (amount.toFloat() / total).coerceIn(0f, 1f) else 0f
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            label,
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            formatRupees(amount),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { fraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = cs.primary,
                        trackColor = cs.primaryContainer,
                        gapSize = 0.dp,
                        drawStopIndicator = {}
                    )
                    Text(
                        "${(fraction * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }
        }
    }
}
