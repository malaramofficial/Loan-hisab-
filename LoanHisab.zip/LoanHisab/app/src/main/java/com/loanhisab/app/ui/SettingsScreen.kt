package com.loanhisab.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.loanhisab.app.util.formatRupees
import com.loanhisab.app.util.paiseToInput
import com.loanhisab.app.util.parseAmountToPaise

@Composable
fun SettingsScreen(
    name: String,
    loanPaise: Long,
    entryCount: Int,
    onNameChange: (String) -> Unit,
    onLoanChange: (Long) -> Unit,
    onExportBackup: () -> Unit,
    onRestore: () -> Unit,
    onExportCsv: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var showNameDialog by rememberSaveable { mutableStateOf(false) }
    var showLoanDialog by rememberSaveable { mutableStateOf(false) }
    var showRestoreConfirm by rememberSaveable { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Text("सेटिंग", style = MaterialTheme.typography.headlineMedium) }

        item {
            SettingsGroup("प्रोफ़ाइल और लोन") {
                SettingRow(
                    icon = Icons.Rounded.Person,
                    title = "आपका नाम",
                    subtitle = name.ifBlank { "नाम जोड़ें" },
                    onClick = { showNameDialog = true }
                )
                SettingRow(
                    icon = Icons.Rounded.AccountBalanceWallet,
                    title = "कुल प्राप्त लोन",
                    subtitle = formatRupees(loanPaise),
                    onClick = { showLoanDialog = true }
                )
            }
        }

        item {
            SettingsGroup("डेटा और बैकअप") {
                SettingRow(
                    icon = Icons.Rounded.Save,
                    title = "बैकअप सेव करें",
                    subtitle = "सभी $entryCount एंट्री एक फ़ाइल में (JSON)",
                    onClick = onExportBackup
                )
                SettingRow(
                    icon = Icons.Rounded.Restore,
                    title = "बैकअप से रिस्टोर करें",
                    subtitle = "पहले सेव की हुई फ़ाइल से डेटा वापस लाएँ",
                    onClick = { showRestoreConfirm = true }
                )
                SettingRow(
                    icon = Icons.Rounded.TableChart,
                    title = "Excel / Sheets के लिए CSV",
                    subtitle = "एंट्री की सूची CSV फ़ाइल में सेव करें",
                    onClick = onExportCsv
                )
            }
        }

        item {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "आपका डेटा सिर्फ़ इसी फ़ोन में है",
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onPrimaryContainer
                    )
                    Text(
                        "यह ऐप किसी वेबसाइट या सर्वर से नहीं जुड़ता और इंटरनेट की ज़रूरत नहीं है। " +
                            "ऐप अनइंस्टॉल करने या फ़ोन बदलने से पहले बैकअप ज़रूर सेव कर लें, " +
                            "वरना डेटा चला जाएगा।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onPrimaryContainer
                    )
                }
            }
        }
    }

    if (showNameDialog) {
        TextInputDialog(
            title = "आपका नाम",
            label = "नाम",
            initial = name,
            keyboardType = KeyboardType.Text,
            validate = { null },
            onDismiss = { showNameDialog = false },
            onConfirm = {
                onNameChange(it)
                showNameDialog = false
            }
        )
    }

    if (showLoanDialog) {
        TextInputDialog(
            title = "कुल प्राप्त लोन",
            label = "रकम (रुपये)",
            initial = if (loanPaise == 0L) "" else paiseToInput(loanPaise),
            keyboardType = KeyboardType.Decimal,
            validate = { if (parseAmountToPaise(it, allowZero = true) == null) "सही रकम लिखें" else null },
            onDismiss = { showLoanDialog = false },
            onConfirm = {
                parseAmountToPaise(it, allowZero = true)?.let(onLoanChange)
                showLoanDialog = false
            }
        )
    }

    if (showRestoreConfirm) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirm = false },
            title = { Text("रिस्टोर करें?") },
            text = {
                Text("अभी की सारी एंट्री, नाम और लोन की राशि बैकअप फ़ाइल के डेटा से बदल जाएँगे। अगर चाहें तो पहले मौजूदा डेटा का बैकअप सेव कर लें।")
            },
            confirmButton = {
                TextButton(onClick = {
                    showRestoreConfirm = false
                    onRestore()
                }) { Text("फ़ाइल चुनें", fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showRestoreConfirm = false }) { Text("रद्द करें") } }
        )
    }
}

@Composable
private fun SettingsGroup(title: String, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.labelLarge,
            color = cs.onSurfaceVariant,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 4.dp)
        )
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = cs.surface),
            border = BorderStroke(1.dp, cs.outline)
        ) {
            Column { content() }
        }
    }
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .background(cs.primaryContainer, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = cs.primary)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant
            )
        }
    }
}
