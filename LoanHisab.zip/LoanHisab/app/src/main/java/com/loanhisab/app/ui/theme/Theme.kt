package com.loanhisab.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val GreenPrimary = Color(0xFF1B7A43)
val GreenDark = Color(0xFF14532D)
val GreenLight = Color(0xFFE3F3E8)
val GreenBar = Color(0xFF8FE3A8)
val RedExpense = Color(0xFFB5472F)
val RedLight = Color(0xFFFDECE8)
val Ink = Color(0xFF14231B)
val Muted = Color(0xFF6B7A72)

private val colors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = Color.White,
    primaryContainer = GreenLight,
    onPrimaryContainer = GreenDark,
    secondaryContainer = GreenLight,
    onSecondaryContainer = GreenDark,
    background = Color(0xFFF3F6F4),
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF1F3F2),
    onSurfaceVariant = Muted,
    outline = Color(0xFFDDE3DF),
    outlineVariant = Color(0xFFE6EBE8),
    error = RedExpense,
    onError = Color.White,
    errorContainer = RedLight,
    onErrorContainer = RedExpense
)

// देवनागरी में ऊपर-नीचे मात्राएँ कटें नहीं, इसलिए lineHeight थोड़ा खुला रखा है।
private val base = Typography()
private val typography = Typography(
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold, lineHeight = 40.sp),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold, lineHeight = 30.sp),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold, lineHeight = 26.sp),
    titleSmall = base.titleSmall.copy(lineHeight = 22.sp),
    bodyLarge = base.bodyLarge.copy(lineHeight = 26.sp),
    bodyMedium = base.bodyMedium.copy(lineHeight = 22.sp),
    bodySmall = base.bodySmall.copy(lineHeight = 18.sp),
    labelLarge = base.labelLarge.copy(lineHeight = 22.sp),
    labelMedium = base.labelMedium.copy(lineHeight = 18.sp),
    labelSmall = base.labelSmall.copy(lineHeight = 16.sp)
)

@Composable
fun LoanHisabTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, typography = typography, content = content)
}
