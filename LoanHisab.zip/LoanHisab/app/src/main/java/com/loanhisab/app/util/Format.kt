package com.loanhisab.app.util

import java.time.LocalDate
import java.time.YearMonth

private val HINDI_MONTHS = listOf(
    "जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून",
    "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
)

/** पैसे (paise) को भारतीय ढंग में दिखाता है: 753322 पैसे के बजाय ₹7,53,322 */
fun formatRupees(paise: Long): String {
    val negative = paise < 0
    val abs = kotlin.math.abs(paise)
    val rupees = (abs / 100).toString()
    val fraction = abs % 100

    val grouped = if (rupees.length <= 3) {
        rupees
    } else {
        val last3 = rupees.takeLast(3)
        var rest = rupees.dropLast(3)
        val parts = ArrayList<String>()
        while (rest.length > 2) {
            parts.add(0, rest.takeLast(2))
            rest = rest.dropLast(2)
        }
        if (rest.isNotEmpty()) parts.add(0, rest)
        parts.joinToString(",") + "," + last3
    }

    val tail = if (fraction == 0L) "" else String.format(".%02d", fraction)
    return (if (negative) "−" else "") + "₹" + grouped + tail
}

/** इनपुट बॉक्स में दिखाने के लिए सादा नंबर (कॉमा के बिना) */
fun paiseToInput(paise: Long): String =
    if (paise % 100 == 0L) (paise / 100).toString()
    else String.format("%d.%02d", paise / 100, paise % 100)

/**
 * टाइप की हुई रकम को पैसे में बदलता है। हिंदी अंक (१२३), कॉमा और ₹ चलेंगे।
 * गलत या ज़ीरो रकम (allowZero=false पर) के लिए null लौटाता है।
 */
fun parseAmountToPaise(input: String, allowZero: Boolean = false): Long? {
    val cleaned = input.trim()
        .map { c -> if (c in '०'..'९') '0' + (c - '०') else c }
        .joinToString("")
        .replace(",", "")
        .replace("₹", "")
        .replace(" ", "")
    if (cleaned.isEmpty() || !Regex("^\\d*\\.?\\d*$").matches(cleaned)) return null
    val value = cleaned.toBigDecimalOrNull() ?: return null
    if (value.stripTrailingZeros().scale() > 2) return null
    val paise = value.movePointRight(2).toBigInteger()
    if (paise.bitLength() > 62) return null
    val result = paise.toLong()
    return if (result == 0L && !allowZero) null else result
}

fun formatDate(epochDay: Long): String {
    val d = LocalDate.ofEpochDay(epochDay)
    return "${d.dayOfMonth}/${d.monthValue}/${d.year}"
}

fun monthOf(epochDay: Long): YearMonth = YearMonth.from(LocalDate.ofEpochDay(epochDay))

fun monthLabel(ym: YearMonth): String = "${HINDI_MONTHS[ym.monthValue - 1]} ${ym.year}"
